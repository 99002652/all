package com.example.screen3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adap extends RecyclerView.Adapter<Adap.exViewHolder> {



    private ArrayList<Listfragment> mexampleList;

    @NonNull
    @Override
    public exViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_listfragment,parent,false);
        exViewHolder evh=new exViewHolder(v);
        return evh;
    }

    @Override
    public void onBindViewHolder(@NonNull exViewHolder holder, int position) {
        Listfragment crrentitem=mexampleList.get(position);
        holder.mimageView.setImageResource(crrentitem.getImg());
        holder.mTextView1.setText(crrentitem.getText1());
        holder.mTextView2.setText(crrentitem.getText2());
    }

    @Override
    public int getItemCount() {
        return mexampleList.size();
    }

    public static class exViewHolder extends RecyclerView.ViewHolder{
        public ImageView mimageView;
        public TextView mTextView1;
        public TextView mTextView2;


        public exViewHolder(@NonNull View itemView) {
            super(itemView);
            mimageView=itemView.findViewById(R.id.imageview);
            mTextView1=itemView.findViewById(R.id.textView);
            mTextView2=itemView.findViewById(R.id.textView2);

        }
    }
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private CardView cardView;

        public ViewHolder(View itemView) {
            super(itemView);
            cardView = (CardView) itemView.findViewById(R.id.card);
        }
    }
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //implement onClick
                System.out.println("Clicked");

               // Toast.makeText(getActivity(),"Text!",Toast.LENGTH_SHORT).show();
            }
        });
    }
//    private void onClick(View view)
//    {
//        if(view.getId() == R.id.card)
//        {
//            Toast.makeText(getActivity(),"Text!",Toast.LENGTH_SHORT).show();
//        }
//    }
    public Adap(ArrayList<Listfragment> exampleList){
        mexampleList=exampleList;
    }

}
